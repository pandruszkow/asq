from setuptools import setup, find_packages

setup(
    name='text_sponge',
    version='0.1',
    packages=find_packages(),
)

