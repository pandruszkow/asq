from collections import deque
import time

class TextSponge:
    """
    A class that can be used to produce a continuous "typewriter" / "low-baudrate"
    effect when displaying text.

    The sponge exposes two methods - one to feed it new input, and one to yield the
    text currently remaining within the sponge at a constant rate via an iterator.

    The iterator uses a simple heuristic based on a fixed character rate to decide when
    to release a new character. A more intelligent implementation could try to average out
    the character release rate to something based on a rolling average of the rate of text
    absorption, but this is currently not done this way.

    The iterator does not exit until the sponge is closed - ideally, you will set up a
    new sponge, initiate some process that consumes characters from the character_by_character
    iterator, and initiate another process that keeps adding characters to the sponge as
    a separate thread. Then, by closing the sponge, you will signal the iterator caller to
    do whatever it is supposed to do when the text stream reaches its conclusive end.
    """
    def __init__(self, characters_per_second=0.05):
        """
        Initializes the TextSponge with a given rate of characters per second.
        """
        self.text_to_print = deque("")
        self.text = ""
        self.closed = False
        self.delay_between_characters = 1 / characters_per_second

    def __str__(self):
        """
        Returns the current text state as a string.
        """
        return self.text

    def append(self, text):
        """
        Appends text to the existing buffer.
        """
        if self.closed:
            raise Exception("Cannot append to a closed TextSponge.")
        self.text += text
        self.text_to_print.extend(text)

    def close(self):
        """
        Closes the TextSponge, preventing further appending of text.
        """
        self.closed = True

    def all(self):
        """
        Returns all the text once the TextSponge is closed.
        """
        if not self.closed:
            raise Exception("TextSponge must be closed to retrieve all text.")
        return self.text

    def character_by_character(self):
        """
        Yields each character one by one with a delay.
        """
        while True:
            chars_remaining = len(self.text_to_print)
            if chars_remaining > 0:
                char = self.text_to_print.popleft()
                yield char
                time.sleep(self.delay_between_characters)
            elif chars_remaining == 0 and not self.closed:
                time.sleep(0.01)
            elif self.closed:
                break

